import React from "react";
import "./Main.css";
import { Card, Container, Row, Button, ButtonGroup, Form, } from "react-bootstrap";
import like from "./heart.png";
import cmt from "./chat-bubble.png";

function Main(){
}


export default Main;
